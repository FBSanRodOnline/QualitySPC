const XLSX = require('xlsx');
const { jsPDF } = require('jspdf');
const html2canvas = require('html2canvas');
const { webFrame } = require('electron');

/* --- ZOOM LOGIC --- */
window.addEventListener('wheel', (e) => {
  if (e.ctrlKey && e.altKey) {
    e.preventDefault();
    let zoom = webFrame.getZoomLevel();
    if (e.deltaY < 0) zoom += 0.2; else zoom -= 0.2;
    webFrame.setZoomLevel(zoom);
  }
}, { passive: false });

/* --- NAVIGATION LOGIC --- */
const buttons = document.querySelectorAll('.nav-btn');
const sections = document.querySelectorAll('.content-section');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const targetId = button.id.replace('btn-', 'section-');
    buttons.forEach(btn => btn.classList.remove('active'));
    sections.forEach(section => section.classList.remove('active'));
    button.classList.add('active');
    document.getElementById(targetId).classList.add('active');
  });
});

/* --- USER PROFILE LOGIC --- */
const userCompany = document.getElementById('user-company');
const userName = document.getElementById('user-name');
const btnEditUser = document.getElementById('btn-edit-user');
const btnSaveUser = document.getElementById('btn-save-user');
const logoControls = document.getElementById('logo-controls');
const logoPreview = document.getElementById('user-logo-preview');
const logoText = document.getElementById('user-logo-text');
const btnUploadLogo = document.getElementById('btn-upload-logo');
const fileLogo = document.getElementById('file-logo');
const btnRemoveLogo = document.getElementById('btn-remove-logo');

if(localStorage.getItem('qspc_company')) userCompany.value = localStorage.getItem('qspc_company');
if(localStorage.getItem('qspc_name')) userName.value = localStorage.getItem('qspc_name');
const savedLogo = localStorage.getItem('qspc_logo');
if(savedLogo) {
  logoPreview.src = savedLogo;
  logoPreview.style.display = 'block';
  logoText.style.display = 'none';
}

if(btnEditUser) {
  btnEditUser.addEventListener('click', () => {
    userCompany.disabled = false;
    userName.disabled = false;
    btnEditUser.style.display = 'none';
    btnSaveUser.style.display = 'inline-block';
    if(logoControls) logoControls.style.display = 'block'; 
  });
}

if(btnSaveUser) {
  btnSaveUser.addEventListener('click', () => {
    localStorage.setItem('qspc_company', userCompany.value);
    localStorage.setItem('qspc_name', userName.value);
    
    userCompany.disabled = true;
    userName.disabled = true;
    btnSaveUser.style.display = 'none';
    btnEditUser.style.display = 'inline-block';
    if(logoControls) logoControls.style.display = 'none'; 
    
    alert('Settings Saved!');
  });
}

if(btnUploadLogo && fileLogo) {
  btnUploadLogo.addEventListener('click', () => fileLogo.click());
  fileLogo.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const base64 = ev.target.result;
      localStorage.setItem('qspc_logo', base64);
      logoPreview.src = base64;
      logoPreview.style.display = 'block';
      logoText.style.display = 'none';
    };
    reader.readAsDataURL(file);
  });
}

if(btnRemoveLogo) {
  btnRemoveLogo.addEventListener('click', () => {
    localStorage.removeItem('qspc_logo');
    logoPreview.src = '';
    logoPreview.style.display = 'none';
    logoText.style.display = 'block';
    fileLogo.value = '';
  });
}

/* --- PDF EXPORT LOGIC --- */
async function exportPDF(elementId, title) {
  try {
    const element = document.getElementById(elementId);
    if (!window.jspdf || !window.html2canvas) { alert('Error: PDF libs missing'); return; }

    const canvas = await window.html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');

    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    
    const company = localStorage.getItem('qspc_company') || 'My Company';
    const user = localStorage.getItem('qspc_name') || 'User';
    const date = new Date().toLocaleString();
    const logoData = localStorage.getItem('qspc_logo');

    pdf.setFontSize(16);
    pdf.text(title, 10, 15);
    pdf.setFontSize(10);
    pdf.text(`Company: ${company}`, 10, 22);
    pdf.text(`Prepared By: ${user}`, 10, 27);
    pdf.text(`Date: ${date}`, 10, 32);
    
    if (logoData) {
      pdf.addImage(logoData, 'JPEG', pageWidth - 35, 10, 25, 15); 
    }
    
    pdf.line(10, 35, pageWidth - 10, 35);

    const imgProps = pdf.getImageProperties(imgData);
    const imgHeight = (imgProps.height * (pageWidth - 20)) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 10, 40, pageWidth - 20, imgHeight);
    pdf.save(`${title.replace(/\s/g, '_')}_Report.pdf`);

  } catch (error) {
    console.error(error);
    alert('Failed to generate PDF: ' + error.message);
  }
}

document.getElementById('btn-pdf-xbar').addEventListener('click', () => exportPDF('xbar-print-area', 'X-Bar R Chart Report'));
document.getElementById('btn-pdf-cap').addEventListener('click', () => exportPDF('cap-print-area', 'Process Capability Report'));
document.getElementById('btn-pdf-gage').addEventListener('click', () => exportPDF('gage-print-area', 'Gage RR Study'));

/* --- CONSTANTS --- */
const spcConstants = {
  2: { A2: 1.880, D3: 0, D4: 3.267, d2: 1.128 }, 3: { A2: 1.023, D3: 0, D4: 2.574, d2: 1.693 },
  4: { A2: 0.729, D3: 0, D4: 2.282, d2: 2.059 }, 5: { A2: 0.577, D3: 0, D4: 2.114, d2: 2.326 },
  6: { A2: 0.483, D3: 0, D4: 2.004, d2: 2.534 }, 7: { A2: 0.419, D3: 0.076, D4: 1.924, d2: 2.704 },
  8: { A2: 0.373, D3: 0.136, D4: 1.864, d2: 2.847 }, 9: { A2: 0.337, D3: 0.184, D4: 1.816, d2: 2.970 },
  10: { A2: 0.308, D3: 0.223, D4: 1.777, d2: 3.078 }
};

/* --- EXCEL IMPORT HELPERS --- */
function setupImport(btnId, inputId, targetTextId) {
  const btn = document.getElementById(btnId);
  const input = document.getElementById(inputId);
  const target = document.getElementById(targetTextId);
  if(btn && input && target) {
    btn.addEventListener('click', () => input.click());
    input.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if(!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, {type: 'array'});
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const text = XLSX.utils.sheet_to_csv(firstSheet, {FS: "\t"}); 
        target.value = text;
      };
      reader.readAsArrayBuffer(file);
      input.value = '';
    });
  }
}

setupImport('btn-import-xbar', 'file-xbar', 'xbar-data-input');
setupImport('btn-import-cap', 'file-cap', 'capability-data-input');
setupImport('btn-import-gage', 'file-gage', 'gage-data-input');

/* --- X-BAR LOGIC --- */
const xInput = document.getElementById('xbar-data-input');
let xChart1 = null, xChart2 = null;

document.getElementById('btn-clear-data').addEventListener('click', () => {
  xInput.value = '';
  document.getElementById('xbar-results').style.display = 'none';
  document.getElementById('xbar-charts').style.display = 'none';
  if(xChart1) xChart1.destroy(); if(xChart2) xChart2.destroy();
});

document.getElementById('btn-calculate-xbar').addEventListener('click', () => {
  const raw = xInput.value.trim();
  if(!raw) return alert('No data');
  const lines = raw.split('\n');
  let data = [];
  let flatData = [];

  lines.forEach(r => { 
    const v = r.trim().split(/[\t\s,]+/).map(Number); 
    if(v.length>0 && !v.some(isNaN)) {
      data.push(v);
      flatData.push(...v);
    }
  });
  
  if(data.length===0) return alert('Invalid data');

  const subgroupSetting = parseInt(document.getElementById('xbar-subgroup-size').value) || 5;
  
  if (data[0].length === 1 && flatData.length > 1) {
    data = [];
    for (let i = 0; i < flatData.length; i += subgroupSetting) {
      const group = flatData.slice(i, i + subgroupSetting);
      if (group.length === subgroupSetting) { 
        data.push(group);
      }
    }
    if (data.length === 0) return alert(`Not enough data to form subgroups of size ${subgroupSetting}`);
  }

  const n = data[0].length;
  if(n<2 || n>10) return alert(`Subgroup size must be 2-10 (Detected: ${n})`);
  
  let sumX=0, sumR=0; const means=[], ranges=[], labels=[];
  data.forEach((grp, i) => {
    const m = grp.reduce((a,b)=>a+b,0)/n;
    const r = Math.max(...grp)-Math.min(...grp);
    means.push(m); ranges.push(r); labels.push(i+1);
    sumX+=m; sumR+=r;
  });
  const xbb = sumX/data.length; const rb = sumR/data.length;
  const c = spcConstants[n];
  const uclx = xbb+(c.A2*rb), lclx = xbb-(c.A2*rb);
  const uclr = c.D4*rb, lclr = c.D3*rb;

  document.getElementById('res-xdb').innerText=xbb.toFixed(4); document.getElementById('res-rbar').innerText=rb.toFixed(4);
  document.getElementById('res-ucl').innerText=uclx.toFixed(4); document.getElementById('res-lcl').innerText=lclx.toFixed(4);
  document.getElementById('res-uclr').innerText=uclr.toFixed(4); document.getElementById('res-lclr').innerText=lclr.toFixed(4);

  document.getElementById('xbar-results').style.display='block';
  document.getElementById('xbar-charts').style.display='flex';

  setTimeout(() => {
    if(xChart1) xChart1.destroy(); if(xChart2) xChart2.destroy();
    const ctx1 = document.getElementById('chart-xbar').getContext('2d');
    const ctx2 = document.getElementById('chart-range').getContext('2d');
    
    const opts = { responsive:true, maintainAspectRatio:false, scales:{x:{display:true}} };
    xChart1 = new Chart(ctx1, { type:'line', data:{labels, datasets:[{label:'Mean', data:means, borderColor:'blue', tension:0}, {label:'UCL', data:Array(labels.length).fill(uclx), borderColor:'red', pointRadius:0, borderDash:[5,5]}, {label:'LCL', data:Array(labels.length).fill(lclx), borderColor:'red', pointRadius:0, borderDash:[5,5]}, {label:'CL', data:Array(labels.length).fill(xbb), borderColor:'green', pointRadius:0}]}, options:{...opts, plugins:{title:{display:true, text:'X-Bar Chart'}}} });
    xChart2 = new Chart(ctx2, { type:'line', data:{labels, datasets:[{label:'Range', data:ranges, borderColor:'purple', tension:0}, {label:'UCL', data:Array(labels.length).fill(uclr), borderColor:'red', pointRadius:0, borderDash:[5,5]}, {label:'LCL', data:Array(labels.length).fill(lclr), borderColor:'red', pointRadius:0, borderDash:[5,5]}, {label:'CL', data:Array(labels.length).fill(rb), borderColor:'green', pointRadius:0}]}, options:{...opts, plugins:{title:{display:true, text:'R Chart'}}} });
  }, 50);
});

/* --- CAPABILITY LOGIC --- */
const capInput = document.getElementById('capability-data-input');
let hChart = null;

document.getElementById('btn-clear-cap').addEventListener('click', ()=>{
  capInput.value=''; document.getElementById('capability-results').style.display='none'; document.getElementById('capability-charts').style.display='none';
  if(hChart) hChart.destroy();
});

const normalCDF = (x, mean, sigma) => {
  return 0.5 * (1 + erf((x - mean) / (sigma * Math.sqrt(2))));
};
const erf = (z) => {
  let t = 1.0 / (1.0 + 0.5 * Math.abs(z));
  let ans = 1 - t * Math.exp(-z * z - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277)))))))));
  return z >= 0 ? ans : -ans;
};

document.getElementById('btn-calculate-cap').addEventListener('click', ()=>{
  const raw = capInput.value.trim();
  const usl = parseFloat(document.getElementById('cap-usl').value);
  const lsl = parseFloat(document.getElementById('cap-lsl').value);
  const target = parseFloat(document.getElementById('cap-target').value);
  
  if(!raw) return alert('No data');
  if(isNaN(usl) && isNaN(lsl)) return alert('Enter at least one limit (USL/LSL)');

  const rows=raw.split('\n'); const groups=[]; const all=[];
  rows.forEach(r=>{ const v=r.trim().split(/[\t\s,]+/).map(Number); if(v.length>0 && !v.some(isNaN)){groups.push(v); all.push(...v);} });
  if(all.length<2) return alert('Need more data');

  const mean = all.reduce((a,b)=>a+b,0)/all.length;
  const sdOv = Math.sqrt(all.reduce((a,b)=>a+Math.pow(b-mean,2),0)/(all.length-1));
  
  let sdWi = sdOv;
  const n = groups[0].length;
  if(groups.length>1 && n>1 && n<=10 && groups.every(g=>g.length===n)){
    const rb = groups.reduce((s,g)=>s+(Math.max(...g)-Math.min(...g)),0)/groups.length;
    if(spcConstants[n]) sdWi = rb/spcConstants[n].d2;
  } else {
    let sumMR = 0;
    for(let i=1; i<all.length; i++) sumMR += Math.abs(all[i] - all[i-1]);
    const mrBar = sumMR / (all.length - 1);
    sdWi = mrBar / 1.128; 
  }

  const calcInd = (s) => {
    const u = !isNaN(usl)?(usl-mean)/(3*s):Infinity;
    const l = !isNaN(lsl)?(mean-lsl)/(3*s):Infinity;
    const i = (!isNaN(usl)&&!isNaN(lsl))?(usl-lsl)/(6*s):0;
    return {cp:i, cpl:l, cpu:u, cpk:Math.min(u,l)};
  };
  const pot = calcInd(sdWi); 
  const perf = calcInd(sdOv);
  
  let cpm = '--';
  if(!isNaN(target) && !isNaN(usl) && !isNaN(lsl)) {
    const tau = Math.sqrt(Math.pow(sdOv, 2) + Math.pow(mean - target, 2));
    cpm = ((usl - lsl) / (6 * tau)).toFixed(2);
  }

  const ppmCalc = (s) => {
    const low = !isNaN(lsl) ? normalCDF(lsl, mean, s) * 1e6 : 0;
    const high = !isNaN(usl) ? (1 - normalCDF(usl, mean, s)) * 1e6 : 0;
    return { low, high, tot: low+high };
  };
  const obsLow = !isNaN(lsl) ? all.filter(v=>v<lsl).length : 0;
  const obsHigh = !isNaN(usl) ? all.filter(v=>v>usl).length : 0;
  const obsTot = obsLow + obsHigh;
  
  const ppmOv = ppmCalc(sdOv);
  const ppmWi = ppmCalc(sdWi);

  document.getElementById('res-n').innerText = all.length;
  document.getElementById('res-mean').innerText = mean.toFixed(4);
  document.getElementById('res-sd-ov').innerText = sdOv.toFixed(4);
  document.getElementById('res-sd-wi').innerText = sdWi.toFixed(4);

  document.getElementById('res-pp').innerText = perf.cp.toFixed(2);
  document.getElementById('res-ppl').innerText = perf.cpl === Infinity ? '_' : perf.cpl.toFixed(2);
  document.getElementById('res-ppu').innerText = perf.cpu === Infinity ? '_' : perf.cpu.toFixed(2);
  document.getElementById('res-ppk').innerText = perf.cpk.toFixed(2);
  document.getElementById('res-cpm').innerText = cpm;

  document.getElementById('res-cp').innerText = pot.cp.toFixed(2);
  document.getElementById('res-cpl').innerText = pot.cpl === Infinity ? '_' : pot.cpl.toFixed(2);
  document.getElementById('res-cpu').innerText = pot.cpu === Infinity ? '_' : pot.cpu.toFixed(2);
  document.getElementById('res-cpk').innerText = pot.cpk.toFixed(2);

  document.getElementById('ppm-obs-low').innerText = ((obsLow/all.length)*1e6).toFixed(0);
  document.getElementById('ppm-obs-high').innerText = ((obsHigh/all.length)*1e6).toFixed(0);
  document.getElementById('ppm-obs-tot').innerText = ((obsTot/all.length)*1e6).toFixed(0);

  document.getElementById('ppm-exp-ov-low').innerText = ppmOv.low.toFixed(0);
  document.getElementById('ppm-exp-ov-high').innerText = ppmOv.high.toFixed(0);
  document.getElementById('ppm-exp-ov-tot').innerText = ppmOv.tot.toFixed(0);

  document.getElementById('ppm-exp-wi-low').innerText = ppmWi.low.toFixed(0);
  document.getElementById('ppm-exp-wi-high').innerText = ppmWi.high.toFixed(0);
  document.getElementById('ppm-exp-wi-tot').innerText = ppmWi.tot.toFixed(0);

  document.getElementById('capability-results').style.display='block';
  document.getElementById('capability-charts').style.display='flex';

  setTimeout(() => {
    if(hChart) hChart.destroy();
    const ctx = document.getElementById('chart-histogram').getContext('2d');
    
    const minData = Math.min(...all), maxData = Math.max(...all);
    const minLimit = !isNaN(lsl) ? Math.min(lsl, minData) : minData;
    const maxLimit = !isNaN(usl) ? Math.max(usl, maxData) : maxData;
    const padding = (maxLimit - minLimit) * 0.2;
    const plotMin = minLimit - padding;
    const plotMax = maxLimit + padding;
    
    const binCount = Math.max(10, Math.ceil(Math.sqrt(all.length)));
    const step = (plotMax - plotMin) / binCount;
    const bins = Array(binCount).fill(0);
    const labels = [];
    for(let i=0; i<binCount; i++) labels.push((plotMin + (i*step) + (step/2)).toFixed(2));
    
    all.forEach(v => {
      let idx = Math.floor((v - plotMin) / step);
      if(idx >= 0 && idx < binCount) bins[idx]++;
    });

    const normalCurve = (sigma) => {
      return labels.map(l => {
        const x = parseFloat(l);
        return (1 / (sigma * Math.sqrt(2 * Math.PI))) * Math.exp(-0.5 * Math.pow((x - mean) / sigma, 2));
      });
    };
    
    const totalArea = all.length * step; 
    const ovCurve = normalCurve(sdOv).map(y => y * totalArea);
    const wiCurve = normalCurve(sdWi).map(y => y * totalArea);

    hChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          { label: 'Data', data: bins, backgroundColor: '#3498db', order: 2 },
          { label: 'Overall', data: ovCurve, type: 'line', borderColor: 'red', borderDash: [5,5], pointRadius: 0, tension: 0.4, order: 1 },
          { label: 'Within', data: wiCurve, type: 'line', borderColor: 'black', pointRadius: 0, tension: 0.4, order: 0 }
        ]
      },
      options: { responsive:true, maintainAspectRatio:false, plugins: { title: { display: true, text: 'Process Histogram' } } }
    });
  }, 50);
});

/* --- GAGE R&R 6-PACK LOGIC (SMART PARSER v2: SIDE-BY-SIDE FIXED) --- */
const gageInput = document.getElementById('gage-data-input');
let gCharts = {};

document.getElementById('btn-clear-gage').addEventListener('click', ()=>{
  gageInput.value=''; 
  document.getElementById('gage-results').style.display='none'; 
  document.getElementById('gage-charts').style.display='none';
  const configDisplay = document.getElementById('gage-config-display');
  if(configDisplay) configDisplay.style.display = 'none';
  Object.values(gCharts).forEach(c=>c.destroy()); gCharts={};
});

document.getElementById('btn-calculate-gage').addEventListener('click', ()=>{
  const raw = gageInput.value.trim();
  const usl = parseFloat(document.getElementById('gage-usl').value);
  const lsl = parseFloat(document.getElementById('gage-lsl').value);
  const tolerance = (!isNaN(usl) && !isNaN(lsl)) ? (usl - lsl) : parseFloat(document.getElementById('gage-tolerance')?.value) || 0; 
  const sig = parseFloat(document.getElementById('gage-sigma').value)||6.0;

  if(!raw) return alert('No data');

  let m = [];
  
  // 1. PRE-PROCESS: Split into rows to check width
  // We strictly use Tab delimiter first to detect Excel structure
  const rows = raw.split('\n').map(r => r.trim().split(/[\t]+| {2,}/)); // Split by tabs or multiple spaces
  
  // 2. DETECT FORMATS
  
  // --- A. SIDE-BY-SIDE LISTS (e.g. 9 cols: Part|Op|Val | Part|Op|Val | Part|Op|Val) ---
  // If cols >= 6 and divisible by 3, and looks like multiple lists
  if (rows[0].length >= 6 && rows[0].length % 3 === 0) {
      
      // Iterate through rows
      rows.forEach(row => {
          if(row.length < 3) return;
          
          // Iterate through "Blocks" of 3 columns
          for(let j = 0; j < row.length; j += 3) {
              if (j + 2 >= row.length) break;
              
              const p = row[j].trim();
              const o = row[j+1].trim();
              const v = parseFloat(row[j+2]);
              
              // Basic validation: Value must be a number, Operator should not be empty
              if(p && o && !isNaN(v)) {
                  m.push({ p: p, o: o, v: v });
              }
          }
      });
      
  } 
  
  // --- B. WIDE MATRIX (Excel "Part | Op1 | Op2..." format) ---
  else if (rows.length > 0 && rows[0].length > 3) {
    
    let headers = rows[0];
    let colMap = {}; // Maps column Index to Operator Name

    // Detect if Row 0 is actually data (all numbers) or headers (text)
    // We check the second cell (index 1) because index 0 is usually "Part Name"
    const isHeaderRow = headers.length > 1 && isNaN(parseFloat(headers[1]));

    if (isHeaderRow) {
       // LOGIC: Fill in blank headers (merged cells) by carrying forward previous operator name
       let currentOp = "Operator 1";
       for(let c = 1; c < headers.length; c++) {
           let h = headers[c].trim();
           // If header is not empty and not just "try"/"trial", update current Op
           if(h !== "" && !h.toLowerCase().includes('try') && !h.toLowerCase().includes('trial')) {
               currentOp = h;
           }
           colMap[c] = currentOp;
       }
    } else {
       // No headers found (user pasted just numbers). 
       // FALLBACK: Assume 3 columns per Operator (Standard Excel Template behavior)
       for(let c = 1; c < rows[0].length; c++) {
           const opIndex = Math.ceil(c / 3); 
           colMap[c] = `Operator ${opIndex}`;
       }
    }

    // Loop through rows (Start at 1 if we found headers, 0 if data)
    const startRow = isHeaderRow ? 1 : 0;
    
    for (let i = startRow; i < rows.length; i++) {
        const row = rows[i];
        if(row.length < 2) continue; // Skip empty lines

        const partName = row[0].trim(); // Column 0 is always Part

        // Iterate through all measurement columns (starting at index 1)
        for(let c = 1; c < row.length; c++) {
            const val = parseFloat(row[c]);
            if(!isNaN(val)) {
                m.push({
                    p: partName,
                    o: colMap[c] || `Op ${Math.ceil(c/3)}`, 
                    v: val
                });
            }
        }
    }

  } 
  
  // --- C. LONG LIST PARSING (Legacy/Standard 3-Column) ---
  else {
    const lines = raw.split('\n');
    lines.forEach(l => { 
        let parts = l.trim().split('\t');
        if (parts.length < 3) parts = l.trim().split(',');
        if (parts.length < 3) parts = l.trim().split(/\s+/);
        
        if (parts.length >= 3) {
           const val = parseFloat(parts[2]);
           if (!isNaN(val)) {
             m.push({p:parts[0].trim(), o:parts[1].trim(), v:val});
           }
        }
    });
  }

  // --- CALCULATION LOGIC (UNCHANGED BELOW) ---
  if(m.length<4) return alert('Need more data (Parts x Operators x Trials).');

  m.sort((a,b) => (a.p > b.p) ? 1 : ((b.p > a.p) ? -1 : 0));

  const parts=[...new Set(m.map(x=>x.p))].sort();
  const ops=[...new Set(m.map(x=>x.o))].sort();
  
  const trials = m.length/(parts.length*ops.length);
  
  const configDisplay = document.getElementById('gage-config-display');
  if(configDisplay) {
    configDisplay.innerText = `Detected: ${parts.length} Parts, ${ops.length} Operators, ~${Math.round(trials)} Trials`;
    configDisplay.style.display = 'block';
  }

  const getK1 = (t) => (t === 2 ? 0.8862 : 0.5908); 
  const k1 = getK1(Math.round(trials)); 
  const k2 = ops.length===2 ? 0.7071 : 0.5231; 
  const k3 = 0.5231;

  let sumR=0, cntR=0; const opRanges={};
  parts.forEach(p=>{
    ops.forEach(o=>{
      const sub = m.filter(x=>x.p===p && x.o===o).map(x=>x.v);
      if(sub.length>1){
        const r = Math.max(...sub)-Math.min(...sub);
        sumR+=r; cntR++;
        if(!opRanges[o]) opRanges[o]=[]; opRanges[o].push(r);
      }
    });
  });
  const rb = sumR/cntR;
  const EV = rb * k1 * sig;

  const opAvgs = ops.map(o=>{ const sub=m.filter(x=>x.o===o).map(x=>x.v); return sub.reduce((a,b)=>a+b,0)/sub.length; });
  const diffOp = Math.max(...opAvgs)-Math.min(...opAvgs);
  let avSq = Math.pow(diffOp*k2*sig, 2) - (Math.pow(EV,2)/(parts.length*trials));
  const AV = Math.sqrt(Math.max(0, avSq));

  const GRR = Math.sqrt(Math.pow(EV,2)+Math.pow(AV,2));
  const partAvgs = parts.map(p=>{ const sub=m.filter(x=>x.p===p).map(x=>x.v); return sub.reduce((a,b)=>a+b,0)/sub.length; });
  const diffPart = Math.max(...partAvgs)-Math.min(...partAvgs);
  const PV = diffPart * k3 * sig;
  const TV = Math.sqrt(Math.pow(GRR,2)+Math.pow(PV,2));

  const pct = (v)=> ((v/TV)*100).toFixed(2)+'%';
  document.getElementById('res-grr-pct').innerText = pct(GRR);
  document.getElementById('res-ev-pct').innerText = pct(EV);
  document.getElementById('res-av-pct').innerText = pct(AV);
  document.getElementById('res-pv-pct').innerText = pct(PV);
  const ndc = 1.41*(PV/GRR);
  document.getElementById('res-ndc').innerText = Math.floor(ndc);
  
  const gPct = (GRR/TV)*100;
  const status = gPct<=10?"Good": (gPct<=30?"Marginal":"Unacceptable");
  const sEl = document.getElementById('res-gage-status');
  sEl.innerText = status; sEl.style.color = status==="Good"?"green": (status==="Marginal"?"orange":"red");

  document.getElementById('gage-results').style.display='block';
  document.getElementById('gage-charts').style.display='grid';

  setTimeout(() => {
    const draw = (id, type, data, title) => {
      if(gCharts[id]) gCharts[id].destroy();
      const ctx=document.getElementById(id).getContext('2d');
      gCharts[id] = new Chart(ctx, {type, data, options:{responsive:true, maintainAspectRatio:false, plugins:{title:{display:true, text:title}, legend:{display:false}}}});
    };

    draw('chart-gage-comp', 'bar', {labels:['Gage R&R','Repeat','Reprod','PartVar'], datasets:[{data:[(GRR/TV)*100,(EV/TV)*100,(AV/TV)*100,(PV/TV)*100], backgroundColor:['red','orange','gold','blue']}]}, 'Components %');

    const rLabs=[], rDat=[];
    ops.forEach(o=>{ if(opRanges[o]) opRanges[o].forEach(r=>{rLabs.push(o); rDat.push(r);}) });
    const uclr = rb * 3.267; 
    draw('chart-gage-r-op', 'line', {labels:rLabs, datasets:[{data:rDat, borderColor:'purple', tension:0}, {data:Array(rLabs.length).fill(uclr), borderColor:'red', pointRadius:0, borderDash:[5,5]}]}, 'R Chart by Operator');

    const xLabs=[], xDat=[];
    parts.forEach(p=>{ ops.forEach(o=>{ 
      const sub=m.filter(x=>x.p===p && x.o===o).map(x=>x.v); 
      xLabs.push(o); xDat.push(sub.reduce((a,b)=>a+b,0)/sub.length); 
    })});
    const xgm = xDat.reduce((a,b)=>a+b,0)/xDat.length;
    const uclx = xgm + (1.88*rb); const lclx = xgm - (1.88*rb);
    draw('chart-gage-x-op', 'line', {labels:xLabs, datasets:[{data:xDat, borderColor:'blue', tension:0}, {data:Array(xLabs.length).fill(uclx), borderColor:'red', pointRadius:0, borderDash:[5,5]}, {data:Array(xLabs.length).fill(lclx), borderColor:'red', pointRadius:0, borderDash:[5,5]}]}, 'X-Bar by Operator');

    const pLabs=[], pDat=[];
    parts.forEach(p=>{ const sub=m.filter(x=>x.p===p).map(x=>x.v); sub.forEach(v=>{pLabs.push(p); pDat.push(v);}); });
    draw('chart-gage-by-part', 'line', {labels:pLabs, datasets:[{data:pDat, borderColor:'blue', showLine:false, pointRadius:5}]}, 'By Part');

    const oLabs=[], oDat=[];
    ops.forEach(o=>{ const sub=m.filter(x=>x.o===o).map(x=>x.v); sub.forEach(v=>{oLabs.push(o); oDat.push(v);}); });
    draw('chart-gage-by-op', 'line', {labels:oLabs, datasets:[{data:oDat, borderColor:'orange', showLine:false, pointRadius:5}]}, 'By Operator');

    const sets=[]; const colors=['red','blue','green'];
    ops.forEach((o,i)=>{
      const d = parts.map(p=>{ const sub=m.filter(x=>x.p===p && x.o===o).map(x=>x.v); return sub.reduce((a,b)=>a+b,0)/sub.length; });
      sets.push({label:o, data:d, borderColor:colors[i%3], tension:0});
    });
    if(gCharts['chart-gage-interaction']) gCharts['chart-gage-interaction'].destroy();
    gCharts['chart-gage-interaction'] = new Chart(document.getElementById('chart-gage-interaction').getContext('2d'), {
      type:'line', data:{labels:parts, datasets:sets}, options:{responsive:true, maintainAspectRatio:false, plugins:{title:{display:true, text:'Interaction'}, legend:{display:true}}}
    });
  }, 100); 
});